-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 14, 2025 at 05:32 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `csf3107`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `facility` varchar(50) DEFAULT NULL,
  `court` varchar(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `username`, `facility`, `court`, `date`, `start_time`, `end_time`) VALUES
(1, 'Abu', 'badminton', 'Court A', '2025-05-18', '09:00:00', '10:00:00'),
(4, 'Abu', 'badminton', 'Court A', '2025-05-29', '09:00:00', '11:00:00'),
(22, 'Abu', 'badminton', 'Court C', '2025-05-28', '09:00:00', '11:30:00'),
(29, 'Abu', 'gym', NULL, '2025-05-26', '09:00:00', '11:30:00'),
(30, 'Abu', 'swimming', NULL, '2025-05-26', '09:00:00', '13:00:00'),
(31, 'Abu', 'swimming', NULL, '2025-05-26', '23:00:00', '23:30:00'),
(32, 'Abu', 'badminton', 'Court A', '2025-05-26', '09:00:00', '11:30:00'),
(36, 'Ali', 'gym', NULL, '2025-06-07', '09:00:00', '11:00:00'),
(38, 'Abu', 'badminton', 'Court A', '2025-06-09', '09:00:00', '11:00:00'),
(40, 'Abu', 'gym', NULL, '2025-06-04', '09:00:00', '11:00:00'),
(41, 'Abu', 'swimming', NULL, '2025-06-05', '09:00:00', '11:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL CHECK (`rating` between 1 and 5),
  `feedback_text` text NOT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `username`, `rating`, `feedback_text`, `submitted_at`) VALUES
(1, 'Abu', 5, 'Good', '2025-06-02 07:01:34'),
(3, 'Abu', 1, 'Very very good', '2025-06-02 13:41:14'),
(4, 'Abu', 3, 'The pool tile crack, it injured my toe.', '2025-06-02 13:47:25'),
(10, 'Abu', 5, 'cantik', '2025-06-14 14:05:37'),
(11, 'Abu', 5, '', '2025-06-14 14:17:24');

-- --------------------------------------------------------

--
-- Table structure for table `maintenance_schedule`
--

CREATE TABLE `maintenance_schedule` (
  `id` int(11) NOT NULL,
  `facility` varchar(100) NOT NULL,
  `scheduled_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `assigned_staff` varchar(50) DEFAULT NULL,
  `status` enum('Pending','In Progress','Completed') DEFAULT 'Pending',
  `type` varchar(100) DEFAULT NULL,
  `issues` text DEFAULT NULL,
  `staff_comment` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `maintenance_schedule`
--

INSERT INTO `maintenance_schedule` (`id`, `facility`, `scheduled_date`, `start_time`, `end_time`, `assigned_staff`, `status`, `type`, `issues`, `staff_comment`, `updated_at`) VALUES
(3, 'Badminton Court', '2025-06-14', '09:46:00', '11:46:00', 'Amin', 'Completed', 'Inspection', '', 'all good', '2025-06-12 14:06:11'),
(4, 'Swimming Pool', '2025-06-21', '11:20:00', '12:20:00', 'Amin', 'In Progress', 'Repair of Equipment', 'pool tile crack', 'still ordering new tiles', '2025-06-14 14:41:17');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(64) NOT NULL,
  `roles` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `roles`, `email`, `date_of_birth`, `phone_number`) VALUES
(1, 'Amin', '4567', 'maintenance', 'Aming@gmail.com', '1999-12-22', '0134567890'),
(2, 'Ahmad', '1234', 'management', 'Ahmad@gmail.com', '1999-05-13', '0171234567'),
(3, 'Abu', '8888', 'customer', 'Bakar@gmail.com', '1989-05-05', '0199988776'),
(4, 'Ali', '5149', 'customer', 'Alie@gmail.com', '2000-11-23', '0123456789'),
(5, 'John', '45678', 'maintenance', 'John@gmail.com', '1999-12-02', '0117123456'),
(6, 'Fatimah', '78910', 'maintenance', 'Fatimah@gmail.com', '1999-04-12', '0111111111');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `maintenance_schedule`
--
ALTER TABLE `maintenance_schedule`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assigned_staff` (`assigned_staff`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `maintenance_schedule`
--
ALTER TABLE `maintenance_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `maintenance_schedule`
--
ALTER TABLE `maintenance_schedule`
  ADD CONSTRAINT `maintenance_schedule_ibfk_1` FOREIGN KEY (`assigned_staff`) REFERENCES `users` (`username`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
