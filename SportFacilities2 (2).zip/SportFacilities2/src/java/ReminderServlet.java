/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

/**
 *
 * @author dynas
 */


import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class ReminderServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String username = request.getParameter("username");

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // Adjust DB credentials and database name accordingly
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/csf3107", "root", "admin");

            if ("NO".equals(action)) {
                // Delete the upcoming reservation (within 2 days)
                String deleteSql = "DELETE FROM bookings WHERE username = ? AND date >= CURDATE() AND date <= DATE_ADD(CURDATE(), INTERVAL 2 DAY) LIMIT 1";
                stmt = conn.prepareStatement(deleteSql);
                stmt.setString(1, username);
                stmt.executeUpdate();
                request.setAttribute("message", "Reservation cancelled.");
            } else if ("YES".equals(action)) {
                request.setAttribute("message", "Reservation confirmed.");
            }

            request.getRequestDispatcher("reminder.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        } finally {
            try { if (stmt != null) stmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
}
