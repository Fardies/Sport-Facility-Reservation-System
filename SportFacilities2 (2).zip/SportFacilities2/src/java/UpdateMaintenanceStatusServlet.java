/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class UpdateMaintenanceStatusServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");
        String status = request.getParameter("status");
        String comment = request.getParameter("comment");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/csf3107", "root", "admin");

            String updateSQL = "UPDATE maintenance_schedule SET status = ?, staff_comment = ?, updated_at = NOW() WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(updateSQL);
            ps.setString(1, status);
            ps.setString(2, comment);
            ps.setInt(3, Integer.parseInt(id));
            ps.executeUpdate();

            ps.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect("maintenanceDashboard.jsp");
    }
}