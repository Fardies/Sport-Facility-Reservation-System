/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;

public class bookServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String facility = request.getParameter("facility");
        String court = request.getParameter("court"); // may be null for gym/swimming
        String dateStr = request.getParameter("date");
        String startTimeStr = request.getParameter("start_time");
        String endTimeStr = request.getParameter("end_time");

        try {
            LocalDate today = LocalDate.now();
            LocalTime now = LocalTime.now();

            LocalDate selectedDate = LocalDate.parse(dateStr);
            LocalTime selectedStartTime = LocalTime.parse(startTimeStr);
            LocalTime selectedEndTime = LocalTime.parse(endTimeStr);
            
            // after parsing selectedDate and today
if (selectedDate.isBefore(today)) {
    request.setAttribute("error", "Booking failed: You cannot book past dates.");
    forwardBack(request, response, facility);
    return;
}

            // NEW VALIDATION: block past dates
            if (selectedDate.isBefore(today)) {
                request.setAttribute("error", "You cannot book a past date.");
                forwardBack(request, response, facility);
                return;
            }

            // Validation: booking for today, but time is past
            if (selectedDate.equals(today) && !selectedStartTime.isAfter(now)) {
                request.setAttribute("error", "Start time must be later than the current time.");
                forwardBack(request, response, facility);
                return;
            }

            // Validation: end time must be after start time
            if (!selectedEndTime.isAfter(selectedStartTime)) {
                request.setAttribute("error", "End time must be after start time.");
                forwardBack(request, response, facility);
                return;
            }

            // DB connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/csf3107", "root", "admin");

            // Check for overlapping bookings
            String checkQuery = "SELECT * FROM bookings WHERE facility=? AND date=? AND court=? " +
                    "AND NOT (end_time <= ? OR start_time >= ?)";
            PreparedStatement psCheck = con.prepareStatement(checkQuery);
            psCheck.setString(1, facility);
            psCheck.setString(2, dateStr);
            psCheck.setString(3, court);
            psCheck.setString(4, startTimeStr);
            psCheck.setString(5, endTimeStr);

            ResultSet rs = psCheck.executeQuery();
            if (rs.next()) {
                request.setAttribute("error", "This time slot overlaps with another booking.");
                forwardBack(request, response, facility);
                return;
            }

            // Insert booking
            String insertQuery = "INSERT INTO bookings (username, facility, court, date, start_time, end_time) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement psInsert = con.prepareStatement(insertQuery);
            psInsert.setString(1, username);
            psInsert.setString(2, facility);
            psInsert.setString(3, court);
            psInsert.setString(4, dateStr);
            psInsert.setString(5, startTimeStr);
            psInsert.setString(6, endTimeStr);

            int row = psInsert.executeUpdate();
            if (row > 0) {
                response.sendRedirect("customerDashboard.jsp?message=success");
            } else {
                request.setAttribute("error", "Booking failed due to a database error.");
                forwardBack(request, response, facility);
            }

            con.close();
        } catch (Exception e) {
            request.setAttribute("error", "System error: " + e.getMessage());
            forwardBack(request, response, facility);
        }
    }
    
private void forwardBack(HttpServletRequest request, HttpServletResponse response, String facility)
            throws ServletException, IOException {
        String page = "";
        switch (facility) {
            case "badminton":
                page = "badmintonReservation.jsp";
                break;
            case "gym":
                page = "gymReservation.jsp";
                break;
            case "swimming":
                page = "swimmingReservation.jsp";
                break;
        }
        RequestDispatcher rd = request.getRequestDispatcher(page);
        rd.forward(request, response);
    }
}