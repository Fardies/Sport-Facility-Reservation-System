/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class loginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/csf3107", "root", "admin");

            PreparedStatement pst = conn.prepareStatement("SELECT roles FROM users WHERE username = ? AND password = ?");
            pst.setString(1, username);
            pst.setString(2, password);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String roles = rs.getString("roles");

                HttpSession session = request.getSession();
                session.setAttribute("username", username);
                session.setAttribute("roles", roles);

                switch (roles) {
                    case "customer":
                        response.sendRedirect("customerDashboard.jsp");
                        break;
                    case "management":
                        response.sendRedirect("managementDashboard.jsp");
                        break;
                    case "maintenance":
                        response.sendRedirect("maintenanceDashboard.jsp");
                        break;
                    default:
                        response.sendRedirect("login.jsp?error=invalid");
                        break;
                }
            } else {
                response.sendRedirect("login.jsp?error=invalid");
            }

            rs.close();
            pst.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Database error: " + e.getMessage());
        }
    }
}