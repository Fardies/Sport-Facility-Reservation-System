/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class registerServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        String email = request.getParameter("email");
        String dob = request.getParameter("dob");
        String role = request.getParameter("role");

        if (!password.equals(confirmPassword)) {
            response.sendRedirect("register.jsp?error=mismatch");
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/csf3107", "root", "admin");

            // Check if username already exists
            PreparedStatement checkUser = conn.prepareStatement("SELECT * FROM users WHERE username = ?");
            checkUser.setString(1, username);
            ResultSet rsUser = checkUser.executeQuery();
            if (rsUser.next()) {
                response.sendRedirect("register.jsp?error=exists");
                return;
            }

            // Check if email already exists
            PreparedStatement checkEmail = conn.prepareStatement("SELECT * FROM users WHERE email = ?");
            checkEmail.setString(1, email);
            ResultSet rsEmail = checkEmail.executeQuery();
            if (rsEmail.next()) {
                response.sendRedirect("register.jsp?error=emailexists");
                return;
            }

            // Insert the new user
            PreparedStatement insert = conn.prepareStatement(
                "INSERT INTO users (username, password, email, date_of_birth, roles) VALUES (?, ?, ?, ?, ?)");
            insert.setString(1, username);
            insert.setString(2, password);  // For production, hash the password
            insert.setString(3, email);
            insert.setString(4, dob);
            insert.setString(5, role);
            insert.executeUpdate();

            response.sendRedirect("login.jsp");

            insert.close();
            checkUser.close();
            checkEmail.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}