/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class MaintenanceServlet extends HttpServlet {

    private final String JDBC_URL = "jdbc:mysql://localhost/csf3107";
    private final String JDBC_USER = "root";
    private final String JDBC_PASS = "admin";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String facility = request.getParameter("facility").trim();
        String date = request.getParameter("date").trim();
        String startTime = request.getParameter("startTime").trim();
        String endTime = request.getParameter("endTime").trim();
        String type = request.getParameter("type").trim();
        String staff = request.getParameter("staff").trim();
        String issues = request.getParameter("issues").trim();

        boolean conflict = false;
        String conflictDetails = "";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);

            // Check for time conflict
            String conflictQuery = "SELECT * FROM maintenance_schedule WHERE facility = ? AND scheduled_date = ?";
            PreparedStatement checkStmt = conn.prepareStatement(conflictQuery);
            checkStmt.setString(1, facility);
            checkStmt.setString(2, date);
            ResultSet rs = checkStmt.executeQuery();

            while (rs.next()) {
                String existingStart = rs.getString("start_time");
                String existingEnd = rs.getString("end_time");

                if (!(endTime.compareTo(existingStart) <= 0 || startTime.compareTo(existingEnd) >= 0)) {
                    conflict = true;
                    conflictDetails = "⚠️ Time conflict: Overlaps with existing task from " + existingStart + " to " + existingEnd;
                    break;
                }
            }

            if (!conflict) {
                String insertSQL = "INSERT INTO maintenance_schedule (facility, scheduled_date, start_time, end_time, type, assigned_staff, issues) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement insertStmt = conn.prepareStatement(insertSQL);
                insertStmt.setString(1, facility);
                insertStmt.setString(2, date);
                insertStmt.setString(3, startTime);
                insertStmt.setString(4, endTime);
                insertStmt.setString(5, type);
                insertStmt.setString(6, staff);
                insertStmt.setString(7, issues);
                insertStmt.executeUpdate();
                insertStmt.close();
            }

            rs.close();
            checkStmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("conflict", "Error: " + e.getMessage());
        }

        if (conflict) {
            request.setAttribute("conflict", conflictDetails);
        }

        // Redirect back to scheduler so table updates
        RequestDispatcher rd = request.getRequestDispatcher("maintenanceScheduler.jsp");
        rd.forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Optional: redirect GET to POST
        doPost(request, response);
    }
}

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */


    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */

